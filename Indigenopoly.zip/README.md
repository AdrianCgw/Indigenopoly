Contents of the project

arduino_sensor - code reading and processing the sensor inputs
web_publish - code passing the arduino results to the web server
web_server -  code manage the game state, communication with mobile app and SUSI AI
